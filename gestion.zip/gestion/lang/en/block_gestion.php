<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_gestion', language 'en', branch 'MOODLE_20_STABLE'
 *
 * @package    block_gestion
 * @copyright  Jason Hardin
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'Management';
$string['gestion:addinstance'] = 'Add a new block';
$string['gestion:myaddinstance'] = 'Add a new block to My home';
$string['rolestoshow'] = 'Allow users to view all courses';
$string['config'] = 'Configure';
$string['rolestoshowdescription'] = 'L\'affichage de TOUS LES COURS sur Ma Page sera réservé aux rôles selectionnés. Idem dans les cours. </br>
Le bloc gestion prévoit aussi 3 niveaux d\'affichage dans les cours : </br>
- Niveau 1 => limité à Inscriptions, groupes. </br>
- Niveau 2 => avec en plus Paramètres de cours, historiques, participations aux cours, prendre le rôle d\'étudiant.</br> 
- Niveau 3 => incluant aussi Permissions, sauvegarde cours, restauration, importation,...';

$string['gestion_help'] = '<h2 class="helpheading">Procédure</h2>
<dl style="margin-left:0.5em;">
<dt>Copie du cours source vers le panier</dt>
    <dd>You will notice a small "Copy to Sharing Cart" icon which appears after each
        resource or activity in a course.
        Click on that icon to send a copy of that resource/activity into Sharing Cart.
        Only the activity itself, without user data, will be cloned.</dd>
<dt>Copie du panier vers le cours cible</dt>
    <dd>Click a "Copy to course" icon in Sharing Cart and select one of target markers on each section.
        Or click "Cancel" icon which is above those.</dd>
<dt>Gérer dossiers dans le panier</dt>
    <dd>Click a "Move into folder" icon in a Sharing Cart item.
        An input box for new folder name will appear if there\'s no folder.
        Or you can select an existing folder in drop-down list.
        Which will be replaced with an input box if you click "Edit" icon.</dd>
</dl>';