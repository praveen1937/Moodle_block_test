<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

class block_gestion extends block_base {

    /**
     * Initialises the block instance.
     */
    public function init() {
        $this->title = get_string('pluginname', 'block_gestion');
        
        //global $OUTPUT;
		// help for Sharing Cart
		//$helpicon = $OUTPUT->help_icon ('pluginname','block_gestion');
		//print_r($helpicon);
        // $this->title = get_string('pluginname', 'block_gestion').'<div class ="bloc-actions" >'.$helpicon.'</div>' ;
        // $this->title = '<a href="" title ="Bloc spécifique ESPE"</a>'.get_string('pluginname', 'block_gestion').'';
    }
	
    /**
     * Returns an array of formats for which this block can be used.
     *
     * @return array
     */
    public function applicable_formats() {
        return array(
                'site-index' => true,
                'course-category' => true,
                'course-view' => true,
                'course' => true,
                'mod' => true,
                'user'=> true,
                'my' => true,
                'all' =>true
        );
    }
    
     /**
     * All multiple instances of this block
     * @return bool Returns false
     */
    function instance_allow_multiple() {
        return false;
    }
    
    function has_config() {
		return true;
	}
	
	function instance_can_be_docked() {
        return (parent::instance_can_be_docked() && (empty($this->config->enabledock) || $this->config->enabledock=='yes'));
    }
	
	function get_required_javascript() {
        parent::get_required_javascript();
        $arguments = array(
            'id' => $this->instance->id,
            'instance' => $this->instance->id,
            'candock' => $this->instance_can_be_docked()
        );
        $this->page->requires->yui_module('moodle-block_navigation-navigation', 'M.block_navigation.init_add_tree', array($arguments));
    }


    /**
     * Generates the content of the block and returns it.
     *
     * If the content has already been generated then the previously generated content is returned.
     *
     * @return stdClass
     */
    public function get_content() {
        global $CFG, $COURSE, $USER, $PAGE, $OUTPUT, $DB;
    
        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = new stdClass;
        $this->content->footer = '';
        $this->content->text   = '';

        if (empty($this->instance)) {
            return $this->content;
        }
        
        $courseid = $COURSE->id;
        $course = $this->page->course;
        $context = context_course::instance($course->id, MUST_EXIST);
        $contextid = $context->id; //Contexte lié aux cours
        $context1 = $this->page->context;
        $contextcat = $context1->id; //Contexte lié aux catégories
        $url = $this->page->url->out(); //URL en cours : l'affichage de l'URL est obtenu avec out()
        $contextlevel1 = $PAGE->context->contextlevel;

        //$this->page->requires->js('/blocks/gestion/js/listmenu.js');
        //$PAGE->requires->js('/blocks/gestion/js/listmenu.js');
    /*           
        print_r($courseid);
        echo '<hr>';
        print_r($context1);
        echo '<hr>';
        print_r($contextcat);
        echo '<hr>';
        print_r($contextlevel1);
    */    
         
//GESTION DES CAPACITES
    // AFICHAGE PAGE ACCUEIL, CATEGORIES...
        //Capacités système
        $categorie  = has_capability('moodle/category:manage', $context1);       // Gérer et modifier catégorie, 
        $role       = has_capability('moodle/role:assign', $context1);           // Attribuer roles
        $cohorte    = has_capability('moodle/cohort:manage', $context1);         // Gérer les cohortes
        $restore    = has_capability('moodle/restore:restorecourse', $context1); // Restaurer cours
        //Capacités cours
        $prof3 = has_capability('moodle/course:create', $context);          // Prof niveau 3 (permissions, sauvegarde cours, restauration, importation, reinitialisation cours, banque questions, se connecter en tant que..., tous les cours)
        $prof2 = has_capability('moodle/course:changefullname', $context);  // Prof niveau 2 (paramètres cours, historiques, participation au cours, prendre le rôle étudiant)
        $prof1 = has_capability('moodle/course:movesections', $context);    //Prof niveau 1 (inscriptions, groupes)
        //Capacités notes
        
        $note2 = has_capability('moodle/grade:viewall', $context);          // Evaluer (voir toutes les notes)
        $note1 = has_capability('moodle/grade:view', $context);             // Résultats (voir ses notes)   

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// AFFICHAGE MENU DANS UNE CATEGORIE======================================================
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++        
        $category  = optional_param('categoryid', 0,PARAM_INT); // On prend l'ID category dans l'URL
        if ($category) { // Si une catégorie est affichée...
            if ($categorie) { 
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/edit.png', 'class' => 'icon'));  
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/course/management.php?categoryid='.$category.'" title ="Permet d\'organiser les cours en respectant une hiérarchie en cohérence avec les formations à l\'ESPE.">Gérer cette catégorie</a></br>';
                    
                //$this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/edit.png', 'class' => 'icon'));  
                //$this->content->text .= '<a href="'.$CFG->wwwroot.'/course/editcategory.php?id='.$category.'"</a>Modifier cette catégorie</br>';
            }
            if ($role) {
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/assignroles.png', 'class' => 'icon'));  
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/admin/roles/assign.php?contextid='.$contextcat.'" title =" Permet d\'attribuer un rôle à un utilisateur dans un certain contexte, en lui accordant les permissions correspondant à ce rôle, pour le contexte en question et tous les contextes inférieurs.">Attribution des rôles</a></br>';
            }       
            if ($categorie) {   
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/permissions.png', 'class' => 'icon'));  
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/admin/roles/permissions.php?contextid='.$contextcat.'" title ="Permet de mettre en place des dérogations de role en modifiant certaines permissions.">Permissions</a></br>';    
            }
            if ($cohorte) {   
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/cohort.png', 'class' => 'icon'));  
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/cohort/index.php?contextid='.$contextcat.'" title ="Permet de gérer l\'inscription dans des cohortes (site, catégories) afin de systématiser le peuplement des cours concernés (localisation hiérachique et méthode d\'inscription). ">Cohortes</a><hr>';
            }
            if ($restore) {   
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/import.png', 'class' => 'icon'));  
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/backup/restorefile.php?contextid='.$contextcat.'" title ="Permet de restaurer un cours depuis une sauvegarde en appliquant une des stratégies suivantes : écraser les données d\'un cours cible, ajouter les données de n\'importe quel cours, créer un nouveau cours qui est alors dupliqué, choisir les options pour inclure les données des élèves et/ou des fichiers de cours">Restaurer un cours</a><hr>';
            }                  
        }
// FIN AFFICHAGE MENU DANS UNE CATEGORIE==================================================

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// AFFICHAGE MENU EN DEHORS DES COURS (Page d'accueil, Cours, Ma page)====================
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        if ((isloggedin()) and (($contextlevel1 == CONTEXT_SYSTEM) or ($contextlevel1 == CONTEXT_USER))) {// SI CONTEXT_SYSTEM ou CONTEXT_USER
        
            //MESSAGES PERSONNELS
            $user = $USER->id;
            $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/email.gif', 'class' => 'icon'));
            $this->content->text .= '<a href="'.$CFG->wwwroot.'/message/index.php?user1='.$user.'" title ="Permet d\'accéder à un outil simple de messagerie intégré à Moodle">Messages personnels</a><hr>';
            
            // FICHIERS PERSONNELS
            $returnurl = $PAGE->url->out();
            $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/files.png', 'class' => 'icon'));
            $this->content->text .= '<a href="'.$CFG->wwwroot.'/user/files.php?returnurl='.$returnurl.'" title ="Permet de disposer d\'une zone privée pour déposer et stocker des fichiers et des dossiers pouvant être réexploités dans des cours...">Fichiers personnels</a><hr>';
                       
            //MODIFIER PROFIL
            $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/edit.png', 'class' => 'icon'));
            $this->content->text .= '<a href="'.$CFG->wwwroot.'/user/edit.php?id='.$user.'&course='.$courseid.'" title ="Permet de modifier ses informations personnelles : infos générales, avatar, etc.">Modifier mon profil</a><hr>';
            
            
             // MODIFIER LE PROFIL, VOIR HISTORIQUES, SE CONNECTER EN TANT QUE (Procédure réservée aux administrateurs => cours n°1)...    
            //$courseuser  = optional_param('course', 0,PARAM_INT); // Affichage n° cours utilisateur
            $iduser  = optional_param('id', 0,PARAM_INT); // prise en compte id utilisateur
            if (has_capability('moodle/site:config', context_system::instance()) and ($courseid==1) and ($iduser)) { 
            //Affichage du nom utilisateur
            $name = $DB->get_record('user', array('id' => $iduser), 'firstname');
            $nom = $name->firstname;
            $this->content->text .='<h4>'.$nom.'</h4>';
            
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/user.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/report/log/user.php?id='.$iduser.'&course='.$courseid.'&mode=all" Voir tous les historiques de l\'utilisateur">Historiques</a></br>';  
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/user.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/user/editadvanced.php?id='.$iduser.'&course='.$courseid.'" title ="Permet de modifier le profil de l\'utilisateur">Modifier le profil</a></br>';
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/switchrole.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/course/loginas.php?id='.$courseid.'&user='.$iduser.'&sesskey='.sesskey().'" title ="Permet d\'emprunter temporairement l\'accès d\'un utilisateur : diagnostic, dépannage, etc. Nota  : L\'usage doit rester exceptionnel et motivé...">Se connecter en tant que...</a><hr>';
            }
            
            //AFFICHAGE TOUS LES COURS POUR : Gestionnaire cohortes (9), Course creator (2), Manager (1) 
            
            // Choix des rôles (configuration)============================================
            $rolestoshow = $CFG->block_gestion_rolestoshow; //Récupération de la configuration
            $rolesconfig = explode(',',$rolestoshow); // Passage en tableau

            // Requete sur tous les rôles utilisateur=====================================            
            $userroles=array('user'=>$user);
            $sqlroles = "SELECT DISTINCT ra.roleid 
            FROM efor_role_assignments ra
            WHERE ra.userid = :user";
            $req_roles = $DB->get_records_sql($sqlroles, $userroles);
            
            $touscours = 0; //initialisation
            
            foreach ($req_roles as $req_role) { //Pour chaque role utilisateur
                $roleuser = $req_role->roleid;
                if ($rolesconfig) {
                    foreach ($rolesconfig as $roleconfig) {//Pour chaque role configuré
                        if (($roleconfig) == ($roleuser)) {//Test si correspondance
                            $touscours = 1; // Il existe au moins une correspondance
                        }
                    }

                }
            }
            //Si correpondance ou Administrateur site => affichage "Tous les cours"    
            if (($touscours == 1) or (has_capability('moodle/site:config', context_system::instance()))) {
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/withsubcat.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/course/index.php" title ="Permet la consultation de l\'organisation de l\'ensemble des cours via les catégories dans lesquelles ils sont placés. Permet aussi la recherche de cours...">Tous les cours</a><hr>';
                //page accueil efor
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/moodle_host.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/?redirect=0" title ="Accès direct à la page d\'accueil du site...">Page accueil site</a>';
            }
            if (has_capability('moodle/site:config', context_system::instance())) {
                $this->content->text .= '<hr>';
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/moodle_host.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/admin/index.php?cache=1" title ="Accès direct à l\'administration du site">Administration site</a>';
            }
            //Affichage bouton déconnecter
            $this->content->text .='<hr><a href="'.$CFG->wwwroot.'/blocks/gestion/logout.php" title ="IMPORTANT : Afin de garantir que votre accès ne pourra pas être utilisé après vous par quelqu\'un d\'autre, FERMEZ SYSTEMATIQUEMENT VOTRE NAVIGATEUR une fois déconnecté..."><center><img src="'.$CFG->wwwroot.'/blocks/gestion/img/deconnexion.png" alt="Connexion" width="68" height="20" style="vertical-align:text-top; margin-left:auto; margin-right:auto ; text-align:center" class="img-responsive"></center></a>';
        }
 // FIN AFFICHAGE MENU EN DEHORS DES COURS (Page d'accueil, Cours, Ma page================
         
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//AFFICHAGE MENU DANS UN COURS============================================================
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++          

      //   $course1  = optional_param('course', 0,PARAM_INT); // On prend l'ID course dans l'URL
      //  if (($contextlevel1 == 50) and ($courseid <>1) and (!$course1))   // Test si on est dans un cours et pas sur la page d'accueil du site (cours n°1) et pas dans l'affichages des participants du cours (présence de l'ID "course").
      
        if (($contextlevel1 == CONTEXT_COURSE) and ($courseid <>1) and (strstr($url,'/course/view.php'))) { // On test si on est dans un cours et si on est dans la page d'accueil du cours

            //PARAMETRES DU COURS
            if ($prof2) {  
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/settings.png', 'class' => 'icon'));  
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/course/edit.php?id='.$courseid.'" title="Permet de modifier les paramètres du cours : généraux, description, format du cours, apparence, fichiers et dépôts, accès, groupes, etc.">Paramètres cours</a></br>';
            }
                    
            //GESTION UTILISATEURS
            if ($prof1) { // Enseignant basique : niveau 1 
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/enrolusers.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/enrol/users.php?id='.$courseid.'" title="Permet de vérifier ou gérer (selon les droits) l\'inscription des utilisateurs dans le cours. Permet aussi de gérer ponctuellement l\'inscription dans les groupes.">Inscriptions</a></br>';
            } 
            //METHODES INSCRIPTION (SYNCHRONISATION DE COHORTES)
            if ($cohorte) { // gestionnaire cohorte 
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/group.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/enrol/instances.php?id='.$courseid.'"title="Permet de gérer les méthodes d\'inscription au cours avec notamment la synchronisation de cohortes directement dans un groupe du cours">Méthodes d\'inscription</a><hr>';
            }
               
            if ($prof2) { // Enseignant générique : niveau 2 
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/group.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/group/overview.php?id='.$courseid.'"title="Permet de vérifier ou gérer les groupes d\'étudiants à l\'intérieur du cours et d\'assigner des enseignants voire des tuteurs... à ces groupes. Permet aussi de constituer des groupements pour des activités/ressources accessibles uniquement aux membres du groupement...">Groupes</a><hr>';
            }
                
            //GESTION PERMISSIONS
            if ($prof3) {
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/permissions.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/admin/roles/permissions.php?contextid='.$contextid.'" title ="Permet de changer de manière spécifique les capacités et les permissions définies par défaut pour certains rôles.">Permissions</a><hr>';                
            }
                
            //AFFICHAGE RAPPORTS
            if (($course->showreports) and ($prof2)) { // Si affichage rapports autorisé dans le cours et Permission pour role de voir les rapports
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/report.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/report/log/index.php?id='.$courseid.'" title ="Permet de consulter les historiques du cours : activités, utilisateurs, date, rôle, etc.">Historiques </a></br>';
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/report.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/report/participation/index.php?id='.$courseid.'" title =" Permet de consulter le bilan de participation aux activités du cours">Participation au cours</a><hr>';                       
            }
                
            //AFFICHAGE NOTES
            if (($course->showgrades) and (($note1) or ($note2))) { // Si affichage notes autorisé dans le cours et Permission pour role de voir (ses notes ou toutes les notes)  
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/grades.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/grade/report/index.php?id='.$courseid.'"title="Permet aux enseignants de gérer les évaluations et aux étudiants de consulter ses résultats.">Notes</a><hr>';
            }
    
            //OBJECTIFS DU COURS
            if  (has_capability('moodle/grade:manageoutcomes', $context) and ($CFG->enableoutcomes)) { // Si affichage rapports autorisé dans le cours et Permission pour role de voir les rapports
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/outcomes.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/grade/edit/outcome/course.php?id='.$courseid.'" title ="Permet de gérer les évaluations dans le cours à partir de critères spéciques : objectifs, compétences, etc.">Objectifs </a><hr>';                      
            }
 
            //GESTION DE SAUVEGARDE-RESTAURATION / QUESTIONS en utilisant javascript (avec collapsed et expanded)   
            if ($prof3) {
            //Déclaration générale
            $this->content->text .='
                <div class="block_settings">
                    <ul class="block_tree list">
                        <li class="type_course contains_branch collapsed" aria-expanded="false">
                            <p class="tree_item branch">';
                            
                            // Partie Sauvegarde -restauration
                            $this->content->text .='Sauvegarde/restauration    
                            </p>
                            <ul>
                                <li class="type_setting collapsed item_with_icon">
                                    <p class="tree_item leaf">
                                        <a href="'.$CFG->wwwroot.'/backup/import.php?id='.$courseid.'" title ="Permet d\'importer des contenus (ressources, activités) depuis d\'autres cours vers le cours actuel.">
                                        Importation 
                                        <img alt="" class="smallicon navicon"  src="'.$OUTPUT->pix_url('i/navigationitem').'">
                                        </a>
                                    </p>
                                </li>
                                <li class="type_setting collapsed item_with_icon">
                                    <p class="tree_item leaf">
                                        <a href="'.$CFG->wwwroot.'/backup/backup.php?id='.$courseid.'" title =" Sauvegarde cours avec possibilité de paramétrage : sections, modules, données utilisateurs, etc.">
                                        Sauvegarde cours
                                        <img alt="" class="smallicon navicon"  src="'.$OUTPUT->pix_url('i/navigationitem').'">
                                        </a>
                                    </p>
                                </li>
                                <li class="type_setting collapsed item_with_icon">
                                    <p class="tree_item leaf">
                                        <a href="'.$CFG->wwwroot.'/backup/restorefile.php?contextid='.$contextid.'" title ="Restauration cours avec possibilité de paramétrage : nouveau cours, ajout à cours existant, sections, modules, données utilisateurs, etc.">
                                        Restauration
                                        <img alt="" class="smallicon navicon"  src="'.$OUTPUT->pix_url('i/navigationitem').'">
                                        </a>
                                    </p>
                                </li>
                                <li class="type_setting collapsed item_with_icon">
                                    <p class="tree_item leaf">
                                        <a href="'.$CFG->wwwroot.'/course/reset.php?id='.$courseid.'" title =" Permet de vider un cours des données utilisateurs, tout en conservant les ressources et activités qui constituent votre cours. => A MANIPULER AVEC PRECAUTION...">
                                        Réinitialisation cours
                                        <img alt="" class="smallicon navicon"  src="'.$OUTPUT->pix_url('i/navigationitem').'">
                                        </a>
                                    </p>
                                </li>
                            </ul>
                        </li><hr>';
           
            //Partie questions  
                        $this->content->text .='
                        <li class="type_course collapsed contains_branch" aria-expanded="false">
                            <p class="tree_item branch">
                                Banque questions
                            </p>
                            <ul>
                                <li class="type_setting collapsed item_with_icon">
                                    <p class="tree_item leaf">
                                        <a href="'.$CFG->wwwroot.'/question/edit.php?courseid='.$courseid.'"  title =" Permet à l\'enseignant de créer, de prévisualiser et de modifier des questions dans une base de données de catégories de questions. Les questions peuvent être ajoutées aux activités : Test et Leçon.">
                                        Questions
                                        <img alt="" class="smallicon navicon"  src="'.$OUTPUT->pix_url('i/navigationitem').'">
                                        </a>
                                    </p>
                                </li>
                                <li class="type_setting collapsed item_with_icon">
                                    <p class="tree_item leaf">
                                        <a href="'.$CFG->wwwroot.'/question/category.php?courseid='.$courseid.'"  title =" Permet à l\'enseignant de créer, de prévisualiser et de modifier des catégories pour les questions."> 
                                        Catégories
                                        <img alt="" class="smallicon navicon"  src="'.$OUTPUT->pix_url('i/navigationitem').'">
                                        </a>    
                                    </p>
                                </li>
                                <li class="type_setting collapsed item_with_icon">
                                    <p class="tree_item leaf">
                                        <a href="'.$CFG->wwwroot.'/question/import.php?courseid='.$courseid.'"  title =" Permet d\'activer l\'importation de questions de divers formats à partir d\'un fichier texte">
                                        Importer
                                        <img alt="" class="smallicon navicon"  src="'.$OUTPUT->pix_url('i/navigationitem') . '">
                                        </a>
                                    </p>
                                </li>
                                <li class="type_setting collapsed item_with_icon">
                                    <p class="tree_item leaf">
                                        <a href="'.$CFG->wwwroot.'/question/export.php?courseid='.$courseid.'"  title =" Permet d\'activer l\'exportation de catégories (avec toutes les sous-catégories) de questions vers un fichier.">
                                        Exporter
                                        <img alt="" class="smallicon navicon" src="'.$OUTPUT->pix_url('i/navigationitem') . '">
                                        </a>
                                    </p>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div><hr>';    
            }
   
            // PRENDRE LE ROLE ETUDIANT
            if ($prof2) {         
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/user.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/course/switchrole.php?id='.$courseid.'&sesskey='.sesskey().'&switchrole=5&returnurl=/course/view.php?id='.$courseid.'" title ="Permet de tester la manière dont le cours est vu par l\'étudiant. Fin du test en cliquant sur `Retour à mon rôle normal` (sur le bandeau bleu en haut et à droite)">Prendre rôle étudiant</a><hr>';                    
            }   
            
            //PARTICIPANTS
            $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/cohort.png', 'class' => 'icon'));
            $this->content->text .= '<a href="'.$CFG->wwwroot.'/user/index.php?contextid='.$contextid.'"title =" Permet de consulter l\'accès des participants au cours, de leur envoyer des messages, de faire des annotations, de consulter leurs profils détaillés, etc.">Participants</a></br>';
            
            // AFFICHAGE ANNOTATIONS DU COURS
            if ($prof1) {
            $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/unflagged.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/notes/index.php?course='.$courseid.'"title="Permet de consulter et éditer les annotations des utilisateurs du cours.">Annotations</a><hr>';
            }
                              
            //TOUS LES COURS
            if (($prof3) or ($cohorte)) {
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/withsubcat.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/course/index.php" title ="Permet la consultation de l\'organisation de l\'ensemble des cours via les catégories dans lesquelles ils sont placés. Permet aussi la recherche de cours...">Tous les cours</a>';
            }
        }
        
        //Page d'accueil (éviter bloc vide)
        //if ((isloggedin()) and ($contextlevel1 == 50) and ($courseid ==1)) {
        if (($contextlevel1 == 50) and ($courseid ==1)) {
            if (isloggedin()) { // affichage mes cours
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/course.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/my/" title ="Permet d\'afficher la liste des cours auxquels on est inscrit.">Mes cours</a>';
                $this->content->text .='<hr><a href="'.$CFG->wwwroot.'/blocks/gestion/logout.php" title ="IMPORTANT : Afin de garantir que votre accès ne pourra pas être utilisé après vous par quelqu\'un d\'autre, FERMEZ SYSTEMATIQUEMENT VOTRE NAVIGATEUR une fois déconnecté..."><center><img src="'.$CFG->wwwroot.'/blocks/gestion/img/deconnexion.png" alt="Connexion" width="68" height="20" style="vertical-align:text-top; margin-left:auto; margin-right:auto ; text-align:center" class="img-responsive"></center></a>';
            } else { // Affichage bouton Connexion
            $this->content->text .='<a href="'.$CFG->wwwroot.'/login/index.php" title ="Permet de se connecter à la plateforme avec la méthode d\'authentification adaptée à son profil :
1- Utilisateur disposant d\'un SESAME universitaire
2- Utilisateur Rectorat ou étudiant en instance de validation de son inscription administrative"><center><img src="'.$CFG->wwwroot.'/blocks/gestion/img/connexion.png" alt="Connexion" width="133" height="38" style="vertical-align:text-top; margin-left:auto; margin-right:auto ; text-align:center" class="img-responsive"></center></a>';
            }
        }   
  
// MODIFIER LE PROFIL, VOIR HISTORIQUES (capacité permise aux gestionnaires, profs experts) ==========
        $courseuser  = optional_param('course', 0,PARAM_INT); // Affichage n° cours utilisateur
        $iduser  = optional_param('id', 0,PARAM_INT); // prise en compte id utilisateur
        
        if (($contextlevel1 == CONTEXT_COURSE) and ($prof3) and (strstr($url,'/user/view.php')) and ($iduser)) { // On test si on est dans un cours et si on consulte le profil d'un utilisateur
            //Affichage du nom utilisateur
            $name = $DB->get_record('user', array('id' => $iduser), 'firstname');
            $nom = $name->firstname;
            $this->content->text .='<h4>'.$nom.'</h4>';
            
            $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/user.png', 'class' => 'icon'));
            $this->content->text .= '<a href="'.$CFG->wwwroot.'/report/log/user.php?id='.$iduser.'&course='.$courseid.'&mode=all" Voir tous les historiques de l\'utilisateur">Historiques</a></br>'; 
            http://localhost:8080/moodle27/report/outline/user.php?id=4&course=5&mode=complete           
            $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/user.png', 'class' => 'icon'));
            $this->content->text .= '<a href="'.$CFG->wwwroot.'/report/outline/user.php?id='.$iduser.'&course='.$courseid.'&mode=complete" Voir le rapport d\'activités de l\'utilisateur">Rapport complet</a></br>'; 
      //  }
            if (has_capability('moodle/site:config', context_system::instance())) {
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/user.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/user/editadvanced.php?id='.$iduser.'&course='.$courseid.'" title ="Permet de modifier le profil de l\'utilisateur">Modifier le profil</a><hr>';
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/switchrole.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/course/loginas.php?id='.$courseid.'&user='.$iduser.'&sesskey='.sesskey().'" title ="Permet d\'emprunter temporairement l\'accès d\'un utilisateur : diagnostic, dépannage, etc. Nota  : L\'usage doit rester exceptionnel et motivé...">Se connecter en tant que</a>';
            } 
        }
// FIN AFFICHAGE MENU DANS UN COURS=======================================================
     
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//AFFICHAGE DANS UN MODULE================================================================
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        if ($contextlevel1 == CONTEXT_MODULE) { // Test si on est dans un module
            $cm = $this->page->context;
            $cmid = $cm->id;
            $instanceid = $cm->instanceid;
            $a = new stdClass;
            $a->type = get_string('modulename', $this->page->cm->modname);
                       
            // AFFICHAGE GENERIQUE MODULES
            $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/manual_item.png', 'class' => 'icon'));
            $this->content->text .= ''.strtoupper($a->type).'</br>'; //Affichage du nom du module en majuscules
                
            if ($prof2) {
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/navigationitem.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/course/modedit.php?update='.$instanceid.'&return=1" title ="Permet de modifier les paramètres du module">Paramètres</a></br>';   
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/navigationitem.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/admin/roles/assign.php?contextid='.$cmid.'" title ="Permet de changer de manière spécifique les capacités et les permissions liés au module">Rôles attribués localement</a></br>'; 
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/navigationitem.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/report/log/index.php?id='.$courseid.'&modid='.$instanceid.'" title ="Permet de consulter les historiques">Historiques</a></br>'; 
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/navigationitem.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/backup/backup.php?id='.$courseid.'&modid='.$instanceid.'" title ="Permet de faire une sauvegarde : cours, module, etc.">Sauvegarde</a></br>'; 
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/navigationitem.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/backup/restorefile.php?contextid='.$cmid.'" title ="permet de restaurer tout ou partie d\'une sauvegarde">Restauration</a><hr>'; 
            }
            // SI MODULE FORUM
            if (($a->type == 'Forum') and ($prof1)) {
                $req_instances = $DB->get_record('course_modules', array('id' => $instanceid,'course' =>$courseid), 'instance', MUST_EXIST);
                //print_r($req_instances->instance);
                        
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/navigationitem.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/mod/forum/subscribers.php?id='.$req_instances->instance.'" title ="Permet d\'afficher/modfier la liste des abonnés au forum.">Abonnés au forum</a><hr>';        
            }
                    
            // SI MODULE DEVOIR
            if ((($a->type == 'Devoir') or ($a->type == 'Assignment')) and ($prof1)) {
                //print_r($a->type);
                $req_id = $DB->get_record('grading_areas', array('contextid' => $cmid), 'id', MUST_EXIST);
                //print_r($req_id->id);
                if ($req_id) {
                        $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/navigationitem.png', 'class' => 'icon'));
                        $this->content->text .= '<a href="'.$CFG->wwwroot.'/grade/grading/manage.php?areaid='.$req_id->id.'" title ="Permet de travailler avec des critères d\'évaluation dans des grilles réutilisables pour plusieurs devoirs dans un cours et de pouvoir aussi les  partager entre collègues.">Evaluation avancée</a><hr>';
                }
            }
            
            // SI MODULE LIVRE (BOOK)
            //Affichage bouton "Activer le mode edition" et "Supprimer le mode edition" pour faciliter l'édition du livre
            if ((($a->type == 'Livre') or ($a->type == 'Book')) and ($prof1) and (strstr($url,'/book/view.php'))) {
                $allowedit  = has_capability('mod/book:edit', $context);
                if ($allowedit) {
                    $buttons = $OUTPUT->edit_button($PAGE->url);
                    $PAGE->set_button($buttons); //Affichage bouton Activer le mode edition et Supprimer le mode edition pour faciliter l'édition du livre
                }    
            }
            
            // SI MODULE PAGE
            //Affichage bouton "Activer le mode edition" et "Supprimer le mode edition" pour faciliter l'édition du livre
            if ((($a->type == 'Page') or ($a->type == 'page')) and ($prof1) and (strstr($url,'/page/view.php'))) {
                $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/navigationitem.png', 'class' => 'icon'));
                $this->content->text .= '<a href="'.$CFG->wwwroot.'/course/modedit.php?update='.$instanceid.'&return=1" title ="Permet de modifier les contenus de la page">Editer la page</a><hr>';    
            }
                        
        //Retour au cours
       // $this->content->text .= '<hr>';
        $this->content->text .= html_writer::empty_tag('img', array('src' => $CFG->wwwroot.'/pix/i/return.png', 'class' => 'icon'));
        $this->content->text .= '<a href="'.$CFG->wwwroot.'/course/view.php?id='.$courseid.'" title ="Retour à la page d\'accueil du cours">Retour au cours</a>';      
        }    
// FIN AFFICHAGE DANS UN MODULE===========================================================   
        return $this->content;
    }
}

