<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Block showing course roster
 *
 * @package   block_gestion
 * @copyright 2013 onwards Johan Reinalda (http://www.thunderbird.edu)
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

if ($ADMIN->fulltree) {
	// get all the global roles
	$choices =  role_fix_names(get_all_roles(), null, ROLENAME_ORIGINAL, true);
    $default = Array();
	$default[1] = 1;	//1 = Manager
	// and then allow each role to be selected for showing in the roster reports.
	// note we store the variable globally (not block specific), so we can get to it from view.php
	// note that we do not use admin_setting_pickroles() since we cannot set defaults there.
	$settings->add(new admin_setting_configmulticheckbox('block_gestion_rolestoshow', get_string('rolestoshow', 'block_gestion'),
	        get_string('rolestoshowdescription', 'block_gestion'), $default, $choices));
	
}